//
//  ViewController.swift
//  Calculator
//
//  Created by User on 05/03/2023.
//

import UIKit




class ViewController: UIViewController {

    
    @IBOutlet weak var textView: UITextView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
 

 @IBAction func btn_one(_ sender: Any) {
        if let url = URL(string: "https://www.google.com/imgres?imgurl=https%3A%2F%2Fupload.wikimedia.org%2Fwikipedia%2Fcommons%2Fc%2Fc4%2FEo_circle_red_number-1.svg&imgrefurl=https%3A%2F%2Fcommons.wikimedia.org%2Fwiki%2FFile%3AEo_circle_red_number-1.svg&tbnid=7Ifcy2oWpuD9uM&vet=12ahUKEwje77-I2sL9AhVvaqQEHdARCZwQMygBegUIARCXAQ..i&docid=jug2L_Ht42irQM&w=800&h=800&q=1&ved=2ahUKEwje77-I2sL9AhVvaqQEHdARCZwQMygBegUIARCXAQ")
        {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)}

    }

    @IBAction func btn_Two(_ sender: Any) {
        if let url = URL(string: "https:www.google.com/imgres?imgurl=https%3A%2F%2Fe7.pngegg.com%2Fpngimages%2F33%2F502%2Fpng-clipart-number-2-image-file-formats-text-thumbnail.png&imgrefurl=https%3A%2F%2Fwww.pngegg.com%2Fen%2Fsearch%3Fq%3Dnumber%2B2&tbnid=utcbFVCi2DooWM&vet=12ahUKEwi24rrU3sL9AhV5pycCHYVcB0AQMygCegUIARCVAQ..i&docid=yJR4Nm7-kv1NoM&w=348&h=348&q=2&ved=2ahUKEwi24rrU3sL9AhV5pycCHYVcB0AQMygCegUIARCVAQ")
        {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)}
    }

    @IBAction func btn_Three(_ sender: Any) {
        if let url = URL(string: "https:www.google.com/imgres?imgurl=https%3A%2F%2Fupload.wikimedia.org%2Fwikipedia%2Fcommons%2Fthumb%2F9%2F9c%2FEo_circle_red_white_number-3.svg%2F1024px-Eo_circle_red_white_number-3.svg.png&imgrefurl=https%3A%2F%2Fcommons.wikimedia.org%2Fwiki%2FFile%3AEo_circle_red_white_number-3.svg&tbnid=9oCAHIFHPBzKxM&vet=12ahUKEwj0xLu238L9AhUhU6QEHfSQAVIQMygNegUIARC0AQ..i&docid=zBVHIvdsQXY8LM&w=1024&h=1024&q=3&ved=2ahUKEwj0xLu238L9AhUhU6QEHfSQAVIQMygNegUIARC0AQ")
        {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)}
    }

    @IBAction func btn_Four(_ sender: Any) {
        if let url = URL(string: "https:www.google.com/imgres?imgurl=https%3A%2F%2Fupload.wikimedia.org%2Fwikipedia%2Fcommons%2Fthumb%2Fb%2Fba%2FNYCS-bull-trans-4-red.svg%2F1200px-NYCS-bull-trans-4-red.svg.png&imgrefurl=https%3A%2F%2Fcommons.wikimedia.org%2Fwiki%2FFile%3ANYCS-bull-trans-4-red.svg&tbnid=JLFElgD3q3bKpM&vet=12ahUKEwi46J_f38L9AhXVmicCHclbAEoQMygRegUIARC6AQ..i&docid=DB7_EQFoyi85SM&w=1200&h=1200&q=4&ved=2ahUKEwi46J_f38L9AhXVmicCHclbAEoQMygRegUIARC6AQ")
        {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)}
    }

    @IBAction func btn_Five(_ sender: Any) {
        if let url = URL(string: "https:www.google.com/imgres?imgurl=https%3A%2F%2Fupload.wikimedia.org%2Fwikipedia%2Fcommons%2Fthumb%2F5%2F5b%2FNYCS-bull-trans-5-red.svg%2F2048px-NYCS-bull-trans-5-red.svg.png&imgrefurl=https%3A%2F%2Fcommons.wikimedia.org%2Fwiki%2FFile%3ANYCS-bull-trans-5-red.svg&tbnid=gy_CsCTAD0JrHM&vet=12ahUKEwjgvPWd4sL9AhV9WaQEHRebCHYQMygTegUIARC_AQ..i&docid=UwuQbF_Djc8QaM&w=2048&h=2048&q=5&ved=2ahUKEwjgvPWd4sL9AhV9WaQEHRebCHYQMygTegUIARC_AQ")
        {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)}
    }


    @IBAction func btn_Six(_ sender: Any) {
        if let url = URL(string: "https://www.google.com/imgres?imgurl=https%3A%2F%2Fupload.wikimedia.org%2Fwikipedia%2Fcommons%2Ff%2Ff3%2FEo_circle_red_number-6.svg&imgrefurl=https%3A%2F%2Fcommons.wikimedia.org%2Fwiki%2FFile%3AEo_circle_red_number-6.svg&tbnid=QaO7ZvNyrA6kuM&vet=12ahUKEwjZ18ab4ML9AhXmXaQEHbc2BZIQMygKegUIARCqAQ..i&docid=DMTtGhyIN0XLEM&w=800&h=800&q=6&ved=2ahUKEwjZ18ab4ML9AhXmXaQEHbc2BZIQMygKegUIARCqAQ")
        {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)}
    }

    @IBAction func btn_Seven(_ sender: Any) {
        if let url = URL(string: "https://www.google.com/imgres?imgurl=https%3A%2F%2Fupload.wikimedia.org%2Fwikipedia%2Fcommons%2Fthumb%2Fc%2Fc9%2FEo_circle_red_number-7.svg%2F2048px-Eo_circle_red_number-7.svg.png&imgrefurl=https%3A%2F%2Fcommons.wikimedia.org%2Fwiki%2FFile%3AEo_circle_red_number-7.svg&tbnid=DMlOpRCmx6OUaM&vet=12ahUKEwi2xeK14ML9AhWFnCcCHdcGAKoQMygEegUIARCgAQ..i&docid=wjYTLURn1I9A8M&w=2048&h=2048&q=7&ved=2ahUKEwi2xeK14ML9AhWFnCcCHdcGAKoQMygEegUIARCgAQ")
        {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)}
    }

    @IBAction func btn_Eight(_ sender: Any) {
        if let url = URL(string: "https://www.google.com/imgres?imgurl=https%3A%2F%2Fweeknumber.net%2Fgfx%2F200x200%2F8.png&imgrefurl=https%3A%2F%2Fweeknumber.net%2F2021%2F8&tbnid=ej_-rL1JuiKC-M&vet=12ahUKEwi28tOl4sL9AhX8uCcCHVhwDCgQMyhDegQIARBP..i&docid=NURXSaE0lIZWvM&w=200&h=200&q=8&ved=2ahUKEwi28tOl4sL9AhX8uCcCHVhwDCgQMyhDegQIARBP")
        {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)}
    }

    @IBAction func btn_Nine(_ sender: Any) {
        if let url = URL(string: "https://www.google.com/imgres?imgurl=https%3A%2F%2Fupload.wikimedia.org%2Fwikipedia%2Fcommons%2Fthumb%2F2%2F2a%2FNYCS-bull-trans-9.svg%2F2048px-NYCS-bull-trans-9.svg.png&imgrefurl=https%3A%2F%2Fcommons.wikimedia.org%2Fwiki%2FFile%3ANYCS-bull-trans-9.svg&tbnid=OtTJNtbBqtyO_M&vet=12ahUKEwiV0tzm4ML9AhX6picCHTH4AqEQMygJegUIARCpAQ..i&docid=PwuTHBm6aOHcTM&w=2048&h=2048&q=9&ved=2ahUKEwiV0tzm4ML9AhX6picCHTH4AqEQMygJegUIARCpAQ")
        {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)}
    }


    @IBAction func btn_Ten(_ sender: Any) {
        if let url = URL(string: "https://www.google.com/imgres?imgurl=https%3A%2F%2Fcdn.pixabay.com%2Fphoto%2F2012%2F04%2F23%2F15%2F09%2Fnumber-38423_1280.png&imgrefurl=https%3A%2F%2Fpixabay.com%2Fvectors%2Fnumber-10-ten-rounded-rectangle-38423%2F&tbnid=Y2Dgk0Xiw4MEkM&vet=12ahUKEwjEn6X34ML9AhVaZqQEHR78CY4QMygCegUIARCXAQ..i&docid=z9WYte7A4pBaMM&w=1280&h=984&q=10&ved=2ahUKEwjEn6X34ML9AhVaZqQEHR78CY4QMygCegUIARCXAQ")
        {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)}
    }

    
//    @IBAction func numbers(_ sender: UITextView) {
//
//        self.textView.text = "1"
//
//    }
    @IBAction func btn_one(_ sender: Any) {
        self.textView.text = "1"
        

    }

    @IBAction func btn_two(_ sender: Any) {
        self.textView.text = "2"

    }
    
    @IBAction func btn_three(_ sender: Any) {
        self.textView.text = "3"

    }
    
    
    @IBAction func btn_four(_ sender: Any) {
        self.textView.text = "4"

    }
    
    @IBAction func btn_five(_ sender: Any) {
        self.textView.text = "5"

    }
    
    
    @IBAction func btn_six(_ sender: Any) {
        self.textView.text = "6"

    }
    
    @IBAction func btn_seven(_ sender: Any) {
        self.textView.text = "7"
    

    }
    
    @IBAction func btn_eight(_ sender: Any) {
        self.textView.text = "8"

    }
    
    @IBAction func btn_ten(_ sender: Any) {
        self.textView.text = "9"

    }
    
    
    @IBAction func btn_nine(_ sender: Any) {
        self.textView.text = "10"

    }
    
    @IBAction func dot(_ sender: UIButton) {
        self.textView.text = "."
    }
    
    @IBAction func equal(_ sender: Any) {
        self.textView.text = "="

    }
    
    
    @IBAction func plus(_ sender: Any) {
        self.textView.text = "+"

        
    }
    
    
    @IBAction func minus(_ sender: Any) {
        self.textView.text = "-"

    }
    
    @IBAction func multiply(_ sender: Any) {
        self.textView.text = "*"

    }
    
    @IBAction func divde(_ sender: Any) {
        self.textView.text = "/"

    }
    
    
    
    
    
}

